package com.example.kirchhoff3d

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val splashDelayMs = 1500L
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showCurrentSplash()
        handler.postDelayed({ showInterface() }, splashDelayMs)
    }

    private fun showCurrentSplash() {
        val background = Color.rgb(9, 19, 34)
        val cyan = Color.rgb(79, 209, 197)
        val text = Color.rgb(232, 238, 249)
        val muted = Color.rgb(170, 184, 205)

        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(background)
            setPadding(24, 24, 24, 24)
        }

        val currentSymbol = TextView(this).apply {
            text = "I  →"
            setTextColor(cyan)
            textSize = 68f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            contentDescription = "Símbolo de corriente eléctrica"
        }
        splash.addView(currentSymbol, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val title = TextView(this).apply {
            text = "Laboratorio 3D de Leyes de Kirchhoff"
            setTextColor(text)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 0)
        }
        splash.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val subtitle = TextView(this).apply {
            text = "Corriente eléctrica · UPIBI · IPN"
            setTextColor(muted)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 0)
        }
        splash.addView(subtitle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        setContentView(splash)
    }

    private fun showInterface() {
        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/kirchhoff3d-android.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
